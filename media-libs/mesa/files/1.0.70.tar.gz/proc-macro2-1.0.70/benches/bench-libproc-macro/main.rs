bench_libproc_macro::bench!();

fn main() {}
