Example output:

```console
$ cargo check --release

   Compiling bench-libproc-macro v0.0.0
STRING: 37 millis
TOKENSTREAM: 276 millis
    Finished release [optimized] target(s) in 1.16s
```
