#![no_std]

pub use unicode_ident::*;
